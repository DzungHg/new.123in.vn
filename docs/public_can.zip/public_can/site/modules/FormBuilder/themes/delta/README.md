# Delta - The Free jQuery UI Theme from Kiandra IT 

### [View Demo](http://kiandra.github.com/Delta-jQuery-UI-Theme)

Licensed under MIT/GPL.