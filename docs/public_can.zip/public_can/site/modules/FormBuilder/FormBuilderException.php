<?php namespace ProcessWire;

/**
 * ProcessWire Form Builder Exception
 *
 * Copyright (C) 2019 by Ryan Cramer Design, LLC
 * 
 * PLEASE DO NOT DISTRIBUTE
 * 
 */

class FormBuilderException extends \Exception { }

