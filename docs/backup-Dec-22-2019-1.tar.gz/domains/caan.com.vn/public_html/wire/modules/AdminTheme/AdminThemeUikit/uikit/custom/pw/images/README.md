This is an exact duplicate of the `/uikit/custom/images/` directory.
It is duplicated because different compilation methods appear to affect
what directory gets referred to for these images. Hopefully we can 
remove this directory at some point in the future. 
